﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using KProcess.Ksmed.Business;
using KProcess.Ksmed.Models;
using KProcess.Ksmed.Presentation.Core;
using $rootnamespace$.Interfaces;
using KProcess.Presentation.Windows;

namespace $rootnamespace$
{
    /// <summary>
    /// Représente le modèle de vue de l'écran ECRANECRANECRANECRANECRAN.
    /// </summary>
	class $safeitemrootname$ : ViewModelBase, I$safeitemrootname$
	{

        #region Champs privés
        
        #endregion

        #region Surcharges
    
        /// <summary>
        /// Méthode appelée lors du chargement
        /// </summary>
        protected override void OnLoading()
        {
        }
    
        /// <summary>
        /// Méthode invoquée lors de l'initialisation du viewModel en mode design
        /// </summary>
        protected override void OnInitializeDesigner()
        {
        }

	    #endregion

        #region Propriétés

        #endregion 

        #region Commandes

        #endregion 

	}
}
