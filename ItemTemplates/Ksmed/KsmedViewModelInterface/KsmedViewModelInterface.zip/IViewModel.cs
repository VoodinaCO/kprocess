﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KProcess.Ksmed.Models;
using KProcess.Ksmed.Presentation.Core;
using KProcess.Presentation.Windows;

namespace $rootnamespace$
{
    /// <summary>
    /// Définit le comportement du modèle de vue de l'écran ECRANECRANECRAN.
    /// </summary>
    [InheritedExportAsPerCall]
    public interface $safeitemrootname$ : IViewModel
    {
    }
}
